#!/bin/bash 
#curl 'http://192.168.12.222:9000/testcase-detail/refresh' -H 'Origin: http://192.168.12.222:9000' -H 'Accept-Encoding: gzip, deflate' -H 'Accept-Language: zh-CN,zh;q=0.8' -H 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36' -H 'content-type: application/json' -H 'accept: application/json' -H 'Referer: http://192.168.12.222:9000/testcase-detail/41126' -H 'Connection: keep-alive' --data-binary '{"testcaseId":41126}' --compressed

tid=$1
#curl 'http://192.168.12.222:9000/testcase-detail/refresh' -H 'Origin: http://192.168.12.222:9000' -H 'Accept-Encoding: gzip, deflate' -H 'Accept-Language: zh-CN,zh;q=0.8' -H 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36' -H 'content-type: application/json' -H 'accept: application/json' -H "Referer: http://192.168.12.222:9000/testcase-detail/$tid" -H 'Connection: keep-alive' --data "{\"testcaseId\":$tid}" --compressed #-o ${tid}.json

curl "http://192.168.12.222:9000/testcase-detail/refresh" -H "content-type: application/json" --data "{\"testcaseId\":$tid}" --compressed -o ${tid}.json
