
if [ "$1" == "" ]; then
  echo Please provide a page number!
  exit 1
fi

curl "http://192.168.12.222:9000/testcases/load?open=yes&page=$1" -H 'content-type: application/json' --data-binary '{"open":"yes", "page":'$1'}' --compressed -o testcases.json

