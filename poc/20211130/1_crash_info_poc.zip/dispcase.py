# -*- coding: utf-8 -*-

import os, sys, json

def fetch_one(id, t):

  print('Fetching id: %s' % id)

  crash_info_file = open('%s_crash_info.txt' % id, 'w')

  os.system('./curl.sh %s' % id)

  with open('%s.json' % id) as f:
    j = json.load(f)

  fuzzer_info = j['fuzzer_display']
  crash_info_file.write('Testcase id: %d\n' % j['id'])
  crash_info_file.write('Job: ' + t['jobType'] + '\n')
  crash_info_file.write('Crash Type: %s\n' % t['crashType'])
  crash_info_file.write('isSecurity: %s\n' % str(t['isSecurity']))
  crash_info_file.write('Crash state: %s\n' % '\n'.join(t['crashStateLines']))
  crash_info_file.write('Poc: %d.testcase\n' % j['id'])

  for k in fuzzer_info.keys():
    crash_info_file.write('%s: %s\n' % (k,fuzzer_info[k]))

  os.system('curl "http://192.168.12.222:9008/test-blobs-bucket/%s\" -o %d.testcase' % (j['testcase']['fuzzed_keys'], j['id']))

  lines = j['crash_stacktrace']['lines']
  for line in lines:
    crash_info_file.write(line['content'].encode('utf8') + '\n')

for page in range(1,6,1):
  print(page)
  os.system('./testcases.sh %d' % page)

  with open('testcases.json', 'r') as f:
    tc = json.load(f)


  for t in tc['items']:
    fetch_one(t['id'], t)
